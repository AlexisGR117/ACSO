#!/bin/bash
clear
lineas=$(wc -l /etc/profile)
echo "El numero de líneas del archivo /ect/profile es:"$lineas

